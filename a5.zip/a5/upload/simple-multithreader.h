#include <iostream>
#include <list>
#include <functional>
#include <stdlib.h>
#include <cstring>
#include <sys/time.h>
#include <pthread.h>


int user_main(int argc, char **argv);

/* Demonstration on how to pass lambda as parameter.
 * "&&" means r-value reference. You may read about it online.
 */
void demonstration(std::function<void()> && lambda) {
  lambda();
}

int main(int argc, char **argv) {
  /* 
   * Declaration of a sample C++ lambda function
   * that captures variable 'x' by value and 'y'
   * by reference. Global variables are by default
   * captured by reference and are not to be supplied
   * in the capture list. Only local variables must be 
   * explicity captured if they are used inside lambda.
   */
  int x=5,y=1;
  // Declaring a lambda expression that accepts void type parameter
  auto /*name*/ lambda1 = /*capture list*/[/*by value*/ x, /*by reference*/ &y](void) {
    /* Any changes to 'x' will throw compilation error as x is captured by value */
    y = 5;
    std::cout<<"====== Welcome to Assignment-"<<y<<" of the CSE231(A) ======\n";
    /* you can have any number of statements inside this lambda body */
  };
  // Executing the lambda function
  demonstration(lambda1); // the value of x is still 5, but the value of y is now 5

  int rc = user_main(argc, argv);
 
  auto /*name*/ lambda2 = [/*nothing captured*/]() {
    std::cout<<"====== Hope you enjoyed CSE231(A) ======\n";
    /* you can have any number of statements inside this lambda body */
  };
  demonstration(lambda2);
  return rc;
}

#define main user_main

typedef struct{
  int low;
  int high;
  std::function<void(int)> function;
} single_thread_args;


void *single_thread_function(void *args){
  single_thread_args* t = static_cast<single_thread_args* > (args);
  for(int i = t->low; i<t->high; i++ ){
    t->function(i);
  }
  pthread_exit(NULL);
}


void parallel_for(int low, int high, std::function<void(int)> &&lambda, int numThreads){
  timeval *start_time;
  timeval *end_time;
  struct timeval execution_time;

  gettimeofday(start_time, NULL);
  pthread_t tid[numThreads];
  single_thread_args args[numThreads];

  if(numThreads<=0){
    perror("Number of threads needs to be atleast 1");
    exit(1);
  }

  int chunk_size = (high - low)/numThreads;
  int remaining_parts = (high - low) % numThreads;

  for(int i = 0; i < numThreads; i++){
    if(i==numThreads-1){
      args[i].high = (i+1)*chunk_size + remaining_parts;
    }else{
      args[i].high = (i+1)*chunk_size
    }
    args[i].function = lambda;

    pthread_create(&tid[i], single_thread_function, static_cast<void*>(&args[i]));
  }

  for (int i=0; i<NTHREADS; i++) {
    pthread_join(tid[i] , NULL);
  }

  gettimeofday(end_time, NULL);

  execution_time.tv_sec = end_time->tv_sec - start_time->tv_sec;
  execution_time.tv_usec = end_time->tv_usec - end_time->tv_usec;
  long long total_execution_time = execution_time.tv_sec*1000 + execution_time.tv_usec/1000;

  printf("The total execution time for this was %lld seconds\n", total_execution_time);
}

typedef struct {
  int low1;
  int high1;
  int low2;
  int high2;
  std::function<void(int, int)> function;
} matrix_thread_args;


void *matrix_thread_function(void * args){
  matrix_thread_args * t = static_cast<matrix_thread_args* > (args);
  for(int i = t->low1; i < t->high1; i++ ){
    for(int j = t->low2; j < t->high2; j++){
      t->function(i,j);
    }
  }
  pthread_exit(NULL);
}

void *parallel_for(int low1, int high1, int low2, int high2, std::function<void(int, int)> &&lambda, int numThreads){
  timeval *start_time;
  timeval *end_time;
  struct timeval execution_time;

  gettimeofday(start_time, NULL);
  pthread_t tid[numThreads];
  matrix_thread_args args[numThreads];

  if(numThreads<=0){
    perror("Number of threads needs to be atleast 1");
    exit(1);
  }

  int chunk_size1 = (high1 - low1) / numThreads;
  int remaining_parts1 = (high1 - low1) % numThreads;
  int chunk_size2 = (high2 - low2) / numThreads;
  int remaining_parts2 = (high2 - low2) % numThreads;

  for(int i = 0; i < numThreads ; i++){
    args[i].low1 = i*chunk_size1;
    args[i].low2 = i*chunk_size2;

    if(i == numThreads-1){
      args[i].high1 = (i+1)*chunk_size1 + remaining_parts1;
      args[i].high2 = (i+1)*chunk_size2 + remaining_parts2;
    }else{
      args[i].high1 = (i+1)*chunk_size1;
      args[i].high2 = (i+1)*chunk_size2;
    }

    args->function = lambda;

    pthread_create(&tid[i], NULL, matrix_thread_function, static_cast<void*>(&args[i]));
  }

  for (int i = 0; i < numThreads; i++) {
    pthread_join(tid[i], NULL);
  }

  gettimeofday(end_time, NULL);

  execution_time.tv_sec = end_time->tv_sec - start_time->tv_sec;
  execution_time.tv_usec = end_time->tv_usec - end_time->tv_usec;
  long long total_execution_time = execution_time.tv_sec*1000 + execution_time.tv_usec/1000;

  printf("The total execution time for this was %lld seconds\n", total_execution_time);
}

